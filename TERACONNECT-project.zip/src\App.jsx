import React, { useState, useEffect } from 'react';
import AboutPage from './pages/AboutPage';
import RegistrationPage from './pages/RegistrationPage';

/**
 * App Root Component
 * Handles client-side routing between the About page (default '/')
 * and the existing Organisation Registration / Onboarding page ('/join').
 */
function App() {
  const getInitialPath = () => {
    if (typeof window === 'undefined') return '/';
    const path = window.location.pathname;
    const hash = window.location.hash;
    if (path === '/join' || path.startsWith('/join') || hash === '#join' || hash === '#/join') {
      return '/join';
    }
    return '/';
  };

  const [currentPath, setCurrentPath] = useState(getInitialPath);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(getInitialPath());
    };

    window.addEventListener('popstate', handlePopState);
    window.addEventListener('hashchange', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('hashchange', handlePopState);
    };
  }, []);

  const navigate = (path) => {
    if (typeof window !== 'undefined') {
      try {
        window.history.pushState(null, '', path);
      } catch {
        window.location.hash = path.replace('/', '#');
      }
    }
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (currentPath === '/join') {
    return <RegistrationPage onNavigateToAbout={() => navigate('/')} />;
  }

  return <AboutPage onNavigateToJoin={() => navigate('/join')} />;
}

export default App;
