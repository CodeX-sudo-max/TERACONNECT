import React, { useState } from 'react';
import { copyToClipboard } from '../utils/helpers';
import bambuDanceGif from '../assets/bambu-dance.gif';

/**
 * SuccessMessage Component
 * Displays the confirmation card with Galactree credentials,
 * energetic victory dancing Bambu mascot GIF,
 * and prominent verified completed status banner.
 */
function SuccessMessage({ savedData, generatedPassword, onReset }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    const textToCopy = `=== TERALOOP SUSTAINABILITY ONBOARDING CREDENTIALS ===\nOrganisation: ${savedData.schoolName}\nCategory: ${savedData.category}\nTeraloop Handle: ${savedData.userId}\nOne-Time Passkey: ${generatedPassword}\nLocation: ${savedData.city}, ${savedData.state} (${savedData.pincode})\nCoordinator: ${savedData.contactName} (+91 ${savedData.mobileNumber})\nStatus: VERIFIED & COMPLETED ✓\nNote: Please rotate passkey on first login.`;
    const success = await copyToClipboard(textToCopy);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  return (
    <div className="success-container">
      <div className="success-card glass-card">
        {/* Prominent Completed Status Banner */}
        <div className="status-banner-completed">
          <span className="status-glow-icon">🎉</span>
          <div className="status-banner-text">
            <span className="status-main-label">ONBOARDING COMPLETED &amp; VERIFIED</span>
            <span className="status-sub-label">Institution successfully rooted in Teraloop Sustainability</span>
          </div>
          <span className="status-verified-badge">✓ 100% ROOTED</span>
        </div>

        {/* Bambu Victory Celebration Dancing Stage (Stationary Frame, Dancing GIF Inside) */}
        <div className="success-mascot-spotlight">
          <div
            className="mascot-celebrate-avatar mascot-avatar-stationary"
            title="Bambu celebrating your completed registration!"
          >
            <div className="mascot-glow-aura aura-victory"></div>

            <img
              src={bambuDanceGif}
              alt="Bambu celebrating"
              className="celebrating-bambu-img mascot-gif-img"
            />
            <div className="mascot-click-hint">
              <span>Victory! 🎉</span>
            </div>
          </div>

          <div className="success-bambu-speech">
            <span className="speech-badge">Bambu's Welcome Anthem:</span>
            <p>
              "WOOHOO! 🎋 Look at that! <strong>{savedData.schoolName}</strong> is now rooted in our planetary movement! Together with Teraloop, we restore forests, conserve fresh water, power up renewables, preserve oil &amp; minerals, defend wildlife, and honor sacred eco-cultures!"
            </p>
          </div>
        </div>

        <h2 className="success-title">Onboarding Completed!</h2>
        <p className="success-subtitle">
          Welcome to <strong>Teraloop</strong>. Your campus is now rooted in the planetary alliance for water conservation, 100% clean energy, preserving finite minerals, wildlife defense, and forest restoration.
        </p>

        {/* Credentials Box */}
        <div className="credentials-box">
          <div className="credentials-header">
            <span className="credentials-tag">🔑 Generated Sign-in Credentials</span>
            <button
              type="button"
              onClick={handleCopy}
              className={`btn-copy ${copied ? 'copied' : ''}`}
            >
              {copied ? '✓ Credentials Copied!' : '📋 Copy All Credentials'}
            </button>
          </div>

          <div className="credentials-body">
            <div className="cred-row">
              <span className="cred-label">Teraloop User ID:</span>
              <span className="cred-value code-pill">{savedData.userId}</span>
            </div>

            <div className="cred-row">
              <span className="cred-label">Temporary Passkey:</span>
              <span className="cred-value code-pill password-highlight">
                {generatedPassword}
              </span>
            </div>
          </div>

          <div className="warning-notice">
            <span className="warning-icon">🎋</span>
            <p className="warning-text">
              <strong>Single-Display Passkey:</strong> Share this securely with coordinator ({savedData.contactName}). They will set their permanent passkey upon initial sign-in.
            </p>
          </div>
        </div>

        {/* Summary Card */}
        <div className="summary-card">
          <h3 className="summary-title">Eco-Registration Record</h3>
          <div className="summary-grid">
            <div>
              <span className="summary-label">Institution Category:</span>
              <span className="summary-val">{savedData.category}</span>
            </div>
            <div>
              <span className="summary-label">Board / Affiliation:</span>
              <span className="summary-val">{savedData.boardType}</span>
            </div>
            <div>
              <span className="summary-label">Affiliation ID:</span>
              <span className="summary-val">{savedData.registrationId}</span>
            </div>
            <div>
              <span className="summary-label">Student Eco-Warriors:</span>
              <span className="summary-val">{savedData.studentCount} Students</span>
            </div>
            <div>
              <span className="summary-label">Location:</span>
              <span className="summary-val">
                {savedData.city}, {savedData.state} ({savedData.pincode})
              </span>
            </div>
            <div>
              <span className="summary-label">Green Ambassador:</span>
              <span className="summary-val">
                {savedData.contactName} (+91 {savedData.mobileNumber})
              </span>
            </div>
            {savedData.email && (
              <div>
                <span className="summary-label">Coordinator Email:</span>
                <span className="summary-val">{savedData.email}</span>
              </div>
            )}
          </div>
        </div>

        {/* Action Button */}
        <div className="success-actions">
          <button
            type="button"
            onClick={onReset}
            className="btn-primary btn-large btn-sprout"
          >
            🌱 Onboard Another Organisation
          </button>
        </div>
      </div>
    </div>
  );
}

export default SuccessMessage;
