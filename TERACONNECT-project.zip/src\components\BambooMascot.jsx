import React, { useState } from 'react';
import mascotWelcomeImg from '../assets/bamboo-mascot.jpg';

const PLANETARY_ECO_FACTS = [
  "💧 Water Conservation: Restoring bamboo and rainforest watersheds naturally purifies runoff and recharges aquifers by up to 40%!",
  "☀️ Renewable Energy: Solar and wind micro-grids allow schools to produce 100% of their power and feed surplus clean energy back to the community!",
  "⛏️ Preserving Oil & Minerals: Bamboo bioplastics and mycelium packaging replace petroleum plastics and reduce deep-earth mineral extraction!",
  "🐾 Wildlife Protection: Institutional green corridors safeguard endangered birds, leopards, and pollinators across urban fringe zones!",
  "🏺 Traditional Eco-Cultures: Indigenous knowledge of sacred groves (like 'Devrai' & 'Oran') has protected biodiversity for over 3,000 years!",
  "🌲 Forest Regeneration: Regrowing multi-canopy forests prevents desertification and sequesters over 30 metric tons of CO2 per hectare annually!"
];

const FIELD_ASSISTANT_DATA = {
  category: {
    title: "Institution Classification",
    speech: "What kind of institution are you registering? Is it a School, University, Corporate hub, or Community space? 🎋",
    tip: "Every category joins our holistic network of water, energy, and biodiversity stewards."
  },
  schoolName: {
    title: "Organisation Identity",
    speech: "What is the proud name of your school or institution? Let's record your name on the Teraloop sustainability scroll! 🏫✨",
    tip: "Use your official campus name so certificates and eco-credits map accurately."
  },
  boardType: {
    title: "Academic Affiliation",
    speech: "Which educational board or governing council guides your curriculum? (e.g. CBSE, ICSE, IB, State Board...) 📚",
    tip: "Board affiliation helps us align climate action modules with your syllabus."
  },
  registrationId: {
    title: "Unique Registry Key",
    speech: "Enter your official registration or affiliation code so we can map your campus coordinates! 🔑",
    tip: "Must be unique in our system to track renewable credits and audits."
  },
  studentCount: {
    title: "Youth Eco-Warriors",
    speech: "How many young minds study under your canopy? Let's calculate our student force for wildlife and water conservation! 🎒🌱",
    tip: "Every 100 students unlocks a community rainwater and biodiversity audit kit."
  },
  address: {
    title: "Ground Coordinates",
    speech: "Where in our beautiful river valley is your campus rooted? Enter your street or campus address! 🗺️",
    tip: "Include sector or landmark to help us map local watershed corridors."
  },
  city: {
    title: "Home City / Town",
    speech: "Which city or town does your campus flourish in? Tell me so we can link your local renewable grid! 🏙️",
    tip: "City name also helps weave your custom Teraloop User ID."
  },
  district: {
    title: "District Region",
    speech: "And which district is that located in? Our wildlife and clean energy networks span every district boundary! 🌿",
    tip: "Used for regional water harvesting and forest conservation scorecards."
  },
  state: {
    title: "State / Union Territory",
    speech: "Select your State or Union Territory from the dropdown to root your organisation locally! 🇮🇳",
    tip: "Helps connect with regional indigenous agro-forestry and wildlife initiatives."
  },
  pincode: {
    title: "Postal Pincode",
    speech: "What is your 6-digit postal code? Enter all 6 numbers so we can deliver your renewable energy and wildlife kit! 📮",
    tip: "Enter a standard 6-digit postal code (e.g. 560100)."
  },
  contactName: {
    title: "Lead Green Ambassador",
    speech: "Who is the chief coordinator or teacher champion representing this institution? Give us their name! 🧑‍🏫💚",
    tip: "They will lead campus zero-waste, water conservation, and solar initiatives."
  },
  mobileNumber: {
    title: "Direct Coordinator Link",
    speech: "Enter a 10-digit mobile number so we can reach your green ambassador with updates and verification codes! 📱",
    tip: "Standard 10-digit mobile number starting with 6, 7, 8, or 9."
  },
  email: {
    title: "Official Email (Optional)",
    speech: "Got an official email address? Enter it here if you'd like sign-in credentials emailed directly! ✉️",
    tip: "Credentials will also be shown securely on your confirmation certificate."
  },
  userId: {
    title: "Teraloop Account Handle",
    speech: "Time to forge your master handle! Pick a unique lowercase User ID, or click 'Suggest Teraloop ID' and I'll craft one for you! 🪄",
    tip: "3 to 32 characters, lowercase letters, numbers, and dots only."
  }
};

/**
 * BambooMascot Component
 * Welcoming Sustainability Guide mascot providing helpful contextual guidance.
 * Kept exclusively to the welcoming pose, without voice synthesis or extra pose buttons.
 */
function BambooMascot({
  focusedField,
  percentage = 0,
  hasErrors = false,
  isSaved = false,
  onQuickFocusNext,
  errors = {},
  onSuggestUserId,
  canSuggest = false
}) {
  const [factIndex, setFactIndex] = useState(0);
  const [isShowingFact, setIsShowingFact] = useState(false);

  // Determine speech text and guidance title
  let speechText = "";
  let speechTitle = "Welcome to Teraloop!";
  let subTip = "";

  if (isSaved) {
    speechTitle = "🎉 Registration Verified & Rooted!";
    speechText = "Hooray! 🎋 Your organisation is officially joined to the Teraloop planetary movement for forest protection, water conservation, clean energy, and wildlife defense!";
    subTip = "Copy your one-time passkey below and share with your coordinator!";
  } else if (hasErrors) {
    speechTitle = "Bambu Guide: A Field Needs Tending 🌿";
    speechText = `I noticed ${Object.keys(errors).length} field(s) that need your care. Take a look at the highlighted sections below and we'll have it sorted in no time!`;
    subTip = "Click into any red highlighted field to see direct formatting instructions.";
  } else if (isShowingFact) {
    speechTitle = "Bambu's Sustainability Wisdom";
    speechText = PLANETARY_ECO_FACTS[factIndex];
    subTip = "Teraloop integrates clean water, renewable power, mineral preservation, and sacred eco-cultures.";
  } else if (focusedField && FIELD_ASSISTANT_DATA[focusedField]) {
    const data = FIELD_ASSISTANT_DATA[focusedField];
    speechTitle = data.title;
    speechText = data.speech;
    subTip = data.tip;
  } else if (percentage === 100) {
    speechTitle = "All Details Connected (100%)!";
    speechText = "Glorious work! All branches of your organisation are documented. Click 'Submit & Complete Onboarding' to seal your covenant!";
  } else if (percentage > 50) {
    speechTitle = `Onboarding ${percentage}% Complete`;
    speechText = `You're over halfway there at ${percentage}%! We are actively connecting your campus to our clean water, solar, and wildlife protection network!`;
  } else {
    speechTitle = "Welcome to Teraloop!";
    speechText = "Hi! I'm Bambu, your Sustainability Guide. 🎋 We protect forests, save clean water, harness solar energy, and safeguard wildlife and traditional eco-cultures. Fill in your details below to begin!";
    subTip = "Click into any field or tap 'Guide Me Next', and I will assist you step by step!";
  }

  const handleNextFact = () => {
    setIsShowingFact(true);
    setFactIndex((prev) => (prev + 1) % PLANETARY_ECO_FACTS.length);
  };

  return (
    <aside
      className={`bamboo-mascot-card virtual-assistant-panel ${isSaved ? 'mascot-completed-card' : ''}`}
      aria-label="Bambu Sustainability Guide"
    >
      {/* Header & Status Indicator */}
      <div className="mascot-header-strip">
        <div className="assistant-identity-wrap">
          <span className="assistant-online-indicator">
            <span className="status-ping"></span>
            <span className="status-core"></span>
          </span>
          <span className="mascot-tag">
            Bambu &bull; Sustainability Guide 🎋
          </span>
        </div>

        <div className="mascot-header-badges">
          {isSaved ? (
            <span className="status-badge-completed">
              <span className="check-sparkle">✓</span> ROOTED 100%
            </span>
          ) : (
            <span className="mascot-progress-chip">
              {percentage}% Complete
            </span>
          )}
        </div>
      </div>

      <div className="mascot-body">
        {/* Stationary Welcoming Avatar Frame */}
        <div
          className="mascot-avatar-wrapper mascot-avatar-stationary"
          onClick={handleNextFact}
          title="Bambu Sustainability Guide. Click for eco wisdom!"
          role="button"
          tabIndex={0}
        >
          <div className="mascot-glow-aura"></div>
          <img
            src={mascotWelcomeImg}
            alt="Bambu Sustainability Guide"
            className="mascot-img avatar-core-img"
          />
          <div className="mascot-click-hint">
            <span>🌿 Welcoming</span>
          </div>
        </div>

        {/* Speech Bubble */}
        <div className="speech-bubble-container">
          <div className="speech-bubble-arrow"></div>
          <div className="speech-bubble assistant-dialogue-bubble">
            <div className="speech-bubble-header">
              <span className="speech-title">{speechTitle}</span>
              <span className="speech-badge">
                Sustainability Guide
              </span>
            </div>

            <p className="speech-content">{speechText}</p>

            {subTip && (
              <div className="assistant-subtip">
                <span className="subtip-icon">💡</span>
                <span className="subtip-text">{subTip}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Action Controls Bar */}
      <div className="mascot-actions-bar">
        <div className="mascot-action-buttons">
          <button
            type="button"
            onClick={handleNextFact}
            className="mascot-action-btn"
            title="Browse water, energy, mineral, and wildlife conservation facts"
          >
            🌍 Sustainability Wisdom
          </button>

          {canSuggest && onSuggestUserId && !isSaved && (
            <button
              type="button"
              onClick={onSuggestUserId}
              className="mascot-action-btn action-suggest"
              title="Auto-generate a smart Teraloop handle"
            >
              🪄 Suggest Teraloop ID
            </button>
          )}

          {!isSaved && onQuickFocusNext && (
            <button
              type="button"
              onClick={onQuickFocusNext}
              className="mascot-action-btn action-highlight"
              title="Auto-scroll to the next unfilled required field"
            >
              🎯 Guide Me Next
            </button>
          )}
        </div>
      </div>
    </aside>
  );
}

export default BambooMascot;
