import React, { useState } from 'react';
import ProgressBar from '../components/ProgressBar';
import OrganisationDetails from '../components/OrganisationDetails';
import LocationDetails from '../components/LocationDetails';
import ContactDetails from '../components/ContactDetails';
import LoginDetails from '../components/LoginDetails';
import SuccessMessage from '../components/SuccessMessage';
import BambooMascot from '../components/BambooMascot';
import { validateField, validateForm, calculateProgress } from '../utils/validation';
import { generateUserIdSuggestion, generateTemporaryPassword } from '../utils/helpers';
import teraloopLogo from '../assets/teraloop-logo.png';
import '../App.css';

// Initial default form state
const initialFormState = {
  category: 'School',
  schoolName: '',
  boardType: '',
  registrationId: '',
  studentCount: '',
  address: '',
  city: '',
  district: '',
  state: '',
  pincode: '',
  contactName: '',
  mobileNumber: '',
  email: '',
  userId: '',
};

const REQUIRED_FIELDS_ORDER = [
  'category',
  'schoolName',
  'boardType',
  'registrationId',
  'studentCount',
  'address',
  'city',
  'district',
  'state',
  'pincode',
  'contactName',
  'mobileNumber',
  'userId'
];

function RegistrationPage({ onNavigateToAbout }) {
  // Main form values state
  const [formData, setFormData] = useState(initialFormState);
  // Form errors state
  const [errors, setErrors] = useState({});
  // Submission loading state (for mock async save)
  const [isSubmitting, setIsSubmitting] = useState(false);
  // Saved state toggle (switches from form to success view)
  const [isSaved, setIsSaved] = useState(false);
  // Generated one-time password
  const [generatedPassword, setGeneratedPassword] = useState('');
  // In-memory list of already registered IDs (for demonstration of uniqueness check)
  const [registeredIds, setRegisteredIds] = useState(['CBSE-DEMO-001', 'ICSE-EXISTING-99', 'TERALOOP-007']);
  // Currently focused field for Bambu the mascot
  const [focusedField, setFocusedField] = useState('');

  // Compute live progress
  const { percentage, sectionStatus } = calculateProgress(formData);

  // Check if User ID suggestion can be activated (requires school name)
  const canSuggestUserId = formData.schoolName.trim().length > 0;

  /**
   * Universal input change handler
   */
  const handleChange = (e) => {
    const { name, value } = e.target;
    const updatedForm = { ...formData, [name]: value };
    setFormData(updatedForm);

    // Clear error for the edited field if it becomes valid
    if (errors[name]) {
      const fieldError = validateField(name, value, updatedForm, registeredIds);
      setErrors((prevErrors) => {
        const newErrors = { ...prevErrors };
        if (!fieldError) {
          delete newErrors[name];
        } else {
          newErrors[name] = fieldError;
        }
        return newErrors;
      });
    }
  };

  /**
   * Field focus handler - informs Bambu which field is active
   */
  const handleFieldFocus = (name) => {
    setFocusedField(name);
  };

  /**
   * Field blur handler
   */
  const handleFieldBlur = () => {
    // Keep the focused field
  };

  /**
   * Quick Jump / Guide Me feature - Bambu finds the first unfilled required field
   */
  const handleQuickFocusNext = () => {
    const nextField = REQUIRED_FIELDS_ORDER.find((fieldName) => {
      const val = formData[fieldName];
      return !val || (typeof val === 'string' && val.trim() === '');
    });

    if (nextField) {
      setFocusedField(nextField);
      const element = document.getElementsByName(nextField)[0];
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTimeout(() => element.focus(), 300);
      }
    }
  };

  /**
   * Suggest User ID based on school name and city
   */
  const handleSuggestUserId = () => {
    if (!formData.schoolName.trim()) return;
    const suggested = generateUserIdSuggestion(formData.schoolName, formData.city);
    const updatedForm = { ...formData, userId: suggested };
    setFormData(updatedForm);

    if (errors.userId) {
      setErrors((prevErrors) => {
        const newErrors = { ...prevErrors };
        delete newErrors.userId;
        return newErrors;
      });
    }
  };

  /**
   * Form submission handler
   */
  const handleSubmit = (e) => {
    e.preventDefault();

    // Run comprehensive form validation
    const formErrors = validateForm(formData, registeredIds);

    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);

      // Scroll to the first erroneous field
      const firstErrorField = Object.keys(formErrors)[0];
      const element = document.getElementsByName(firstErrorField)[0];
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        element.focus();
      }
      return;
    }

    // Initiate submission sequence
    setIsSubmitting(true);

    // Simulate server-side API call and credential generation
    setTimeout(() => {
      const tempPass = generateTemporaryPassword();
      setGeneratedPassword(tempPass);
      setRegisteredIds((prev) => [...prev, formData.registrationId]);
      setIsSubmitting(false);
      setIsSaved(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1200);
  };

  /**
   * Form reset handler
   */
  const handleReset = () => {
    if (window.confirm('Are you sure you want to clear the entire form?')) {
      setFormData(initialFormState);
      setErrors({});
      setIsSaved(false);
      setGeneratedPassword('');
      setFocusedField('');
    }
  };

  return (
    <div className="app-container">
      {/* Green Economy Atmosphere Layer */}
      <div className="tropical-ambient-overlay" aria-hidden="true"></div>

      {/* Top Navigation Header - Matching User's Photo Design */}
      <header className="app-header teraloop-header">
        <div className="header-content teraloop-header-content">
          <div className="teraloop-brand-left">
            <button
              type="button"
              onClick={onNavigateToAbout}
              className="teraloop-logo-link"
              title="Return to About Teraconnect"
              style={{ background: 'none', border: 'none', padding: 0, cursor: onNavigateToAbout ? 'pointer' : 'default', display: 'flex', alignItems: 'center' }}
            >
              <img
                src={teraloopLogo}
                alt="Teraloop - Sustainable Tomorrow, Together"
                className="teraloop-nav-logo"
              />
            </button>
            <div className="teraloop-header-text">
              <div className="teraloop-title-row">
                <span className="teraloop-title-main">Teraloop</span>
                <span className="teraloop-title-dot">•</span>
                <span className="teraloop-title-portal">Sustainability Onboarding Portal</span>
              </div>
              <div className="teraloop-tagline-row">
                <span className="teraloop-tagline-leaf">🌾</span>
                <span className="teraloop-tagline-text">
                  Empowering Educational Institutions for a Sustainable Tomorrow, Together
                </span>
              </div>
            </div>
          </div>

          <div className="teraloop-header-right" style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            {onNavigateToAbout && (
              <button
                type="button"
                onClick={onNavigateToAbout}
                className="btn-back-about"
                style={{
                  background: 'rgba(27, 67, 50, 0.08)',
                  border: '1px solid rgba(27, 67, 50, 0.2)',
                  color: '#1b4332',
                  fontSize: '13px',
                  fontWeight: '700',
                  padding: '7px 16px',
                  borderRadius: '999px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                ← About Teraconnect
              </button>
            )}
            <span className="teraloop-onboarding-badge">
              <span className="onboarding-dot-green"></span>
              Entity Onboarding
            </span>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="main-content">
        {isSaved ? (
          /* Success Screen View */
          <SuccessMessage
            savedData={formData}
            generatedPassword={generatedPassword}
            onReset={handleReset}
          />
        ) : (
          /* Form Entry View */
          <div className="onboarding-flow">
            {/* Page Heading & Holistic Planetary Sustainability Mission */}
            <div className="page-heading">
              <div className="heading-pill">
                <span className="leaf-dot">🌍</span> Holistic Planetary Sustainability &bull; 6 Core Pillars
              </div>
              <h1 className="page-title">Teraloop: Sustainability Onboarding Portal</h1>
              <p className="page-description">
                Empowering educational institutions and organisations for a sustainable tomorrow, together. Root your campus in planetary defense: protecting forests &amp; wildlife, conserving water, harnessing renewables, preserving oil &amp; minerals, and honoring traditional eco-cultures. Bambu, our welcoming sustainability guide, assists your every step!
              </p>

              {/* 6 Holistic Planetary Pillars Strip */}
              <div className="green-pillars-strip">
                <div className="pillar-item">
                  <span className="pillar-icon">🌲</span>
                  <div className="pillar-meta">
                    <span className="pillar-text">Forest Protection</span>
                    <span className="pillar-sub">Canopy &amp; Afforestation</span>
                  </div>
                </div>
                <div className="pillar-item">
                  <span className="pillar-icon">💧</span>
                  <div className="pillar-meta">
                    <span className="pillar-text">Water Conservation</span>
                    <span className="pillar-sub">Aquifers &amp; Watersheds</span>
                  </div>
                </div>
                <div className="pillar-item">
                  <span className="pillar-icon">☀️</span>
                  <div className="pillar-meta">
                    <span className="pillar-text">Renewable Energy</span>
                    <span className="pillar-sub">Solar &amp; Wind Power</span>
                  </div>
                </div>
                <div className="pillar-item">
                  <span className="pillar-icon">⛏️</span>
                  <div className="pillar-meta">
                    <span className="pillar-text">Preserving Minerals &amp; Oil</span>
                    <span className="pillar-sub">Zero Petrochemicals</span>
                  </div>
                </div>
                <div className="pillar-item">
                  <span className="pillar-icon">🐾</span>
                  <div className="pillar-meta">
                    <span className="pillar-text">Wildlife Defense</span>
                    <span className="pillar-sub">Biodiversity Sanctuaries</span>
                  </div>
                </div>
                <div className="pillar-item">
                  <span className="pillar-icon">🏺</span>
                  <div className="pillar-meta">
                    <span className="pillar-text">Traditional Eco-Cultures</span>
                    <span className="pillar-sub">Indigenous Wisdom</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Reactive Virtual Assistant Avatar */}
            <BambooMascot
              focusedField={focusedField}
              percentage={percentage}
              hasErrors={Object.keys(errors).length > 0}
              isSaved={isSaved}
              onQuickFocusNext={handleQuickFocusNext}
              formData={formData}
              errors={errors}
              onSuggestUserId={handleSuggestUserId}
              canSuggest={canSuggestUserId}
            />

            {/* Live Progress Tracker */}
            <ProgressBar
              percentage={percentage}
              sectionStatus={sectionStatus}
            />

            {/* General Form Error Summary Banner (if errors exist on submit) */}
            {Object.keys(errors).length > 0 && (
              <div className="error-banner">
                <span className="error-banner-icon">⚠️</span>
                <div>
                  <strong>Please tend to the highlighted fields:</strong>
                  <p>There are {Object.keys(errors).length} invalid or missing field(s) in the grove below.</p>
                </div>
              </div>
            )}

            {/* Main Form */}
            <form onSubmit={handleSubmit} noValidate>
              {/* Section 1: Organisation Details */}
              <OrganisationDetails
                formData={formData}
                errors={errors}
                onChange={handleChange}
                onFocus={handleFieldFocus}
                onBlur={handleFieldBlur}
              />

              {/* Section 2: Location Details */}
              <LocationDetails
                formData={formData}
                errors={errors}
                onChange={handleChange}
                onFocus={handleFieldFocus}
                onBlur={handleFieldBlur}
              />

              {/* Section 3: Contact Person Details */}
              <ContactDetails
                formData={formData}
                errors={errors}
                onChange={handleChange}
                onFocus={handleFieldFocus}
                onBlur={handleFieldBlur}
              />

              {/* Section 4: Login & User ID Setup */}
              <LoginDetails
                formData={formData}
                errors={errors}
                onChange={handleChange}
                onSuggestUserId={handleSuggestUserId}
                canSuggest={canSuggestUserId}
                onFocus={handleFieldFocus}
                onBlur={handleFieldBlur}
              />

              {/* Form Action Controls */}
              <div className="form-actions-card">
                <button
                  type="button"
                  onClick={handleReset}
                  className="btn-secondary"
                  disabled={isSubmitting}
                >
                  Clear Form
                </button>

                <button
                  type="submit"
                  className={`btn-primary btn-submit ${isSubmitting ? 'btn-loading' : ''}`}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <span className="spinner-wrap">
                      <span className="spinner"></span> Verifying Onboarding...
                    </span>
                  ) : (
                    '🎋 Submit & Complete Onboarding'
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="app-footer">
        <p>Teraloop &copy; 2026. Sustainable Tomorrow, Together. Empowering educational institutions for a sustainable tomorrow. 🎋</p>
      </footer>
    </div>
  );
}

export default RegistrationPage;
