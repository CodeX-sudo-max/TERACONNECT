import React, { useState } from 'react';
import teraloopLogo from '../assets/teraloop-logo-transparent.png';
import heroImg from '../assets/teraconnect-hero.jpg';
import '../AboutPage.css';

/**
 * AboutPage Component
 * Clean, modern, concise, and engaging About page for Teraconnect.
 */
function AboutPage({ onNavigateToJoin }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="about-page-root">
      {/* 3. Header Navigation */}
      <header className="tc-navbar">
        <div className="tc-container tc-nav-inner">
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="tc-nav-brand"
            title="Teraconnect - Home"
          >
            <img
              src={teraloopLogo}
              alt="Teraconnect Logo"
              className="tc-nav-logo"
            />
            <div className="tc-brand-text-wrap">
              <span className="tc-brand-name">Teraconnect</span>
              <span className="tc-brand-sub">Sustainability Management</span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav aria-label="Main Navigation">
            <ul className="tc-nav-links">
              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection('about')}
                  className="tc-nav-link"
                >
                  About
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection('approach')}
                  className="tc-nav-link"
                >
                  Our Approach
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection('sustainability-areas')}
                  className="tc-nav-link"
                >
                  Sustainability Areas
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onNavigateToJoin}
                  className="tc-nav-link"
                >
                  Join the Network
                </button>
              </li>
            </ul>
          </nav>

          {/* Action Button */}
          <div className="tc-nav-actions">
            <button
              type="button"
              onClick={onNavigateToJoin}
              className="tc-btn-primary"
            >
              Join the Network &rarr;
            </button>
            <button
              type="button"
              className="tc-mobile-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? '✕' : '☰'}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div style={{ background: '#ffffff', padding: '16px 24px', borderBottom: '1px solid #e2e8f0' }}>
            <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection('about')}
                  className="tc-nav-link"
                  style={{ width: '100%', textAlign: 'left' }}
                >
                  About
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection('approach')}
                  className="tc-nav-link"
                  style={{ width: '100%', textAlign: 'left' }}
                >
                  Our Approach
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => scrollToSection('sustainability-areas')}
                  className="tc-nav-link"
                  style={{ width: '100%', textAlign: 'left' }}
                >
                  Sustainability Areas
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onNavigateToJoin}
                  className="tc-btn-primary"
                  style={{ width: '100%', justifyContent: 'center', marginTop: '8px' }}
                >
                  Join the Network &rarr;
                </button>
              </li>
            </ul>
          </div>
        )}
      </header>

      {/* 4. Hero Section */}
      <section className="tc-hero-section">
        <div className="tc-container">
          <div className="tc-hero-grid">
            <div className="tc-hero-content">
              <div className="tc-eyebrow">
                <span className="tc-eyebrow-dot"></span>
                SUSTAINABILITY, CONNECTED
              </div>
              <h1 className="tc-hero-title">
                Turning Sustainability Goals Into Meaningful Action.
              </h1>
              <p className="tc-hero-p">
                Sustainability requires more than good intentions. It takes informed decisions, responsible resource management, and collective action. Teraconnect aims to help organisations understand their impact, manage sustainability initiatives, and make measurable progress towards a more sustainable future.
              </p>
              <div className="tc-hero-ctas">
                <button
                  type="button"
                  onClick={() => scrollToSection('about')}
                  className="tc-btn-secondary"
                >
                  Discover Our Mission
                </button>
                <button
                  type="button"
                  onClick={onNavigateToJoin}
                  className="tc-btn-primary"
                >
                  Join the Network &rarr;
                </button>
              </div>
            </div>

            <div className="tc-hero-visual">
              <div className="tc-hero-img-wrap">
                <img
                  src={heroImg}
                  alt="Sustainable modern architecture, smart microgrid, and clean electric transit"
                  className="tc-hero-img"
                />
              </div>

              {/* Floating Analytical Badges */}
              <div className="tc-hero-badge-float badge-top-right">
                <div className="tc-badge-icon">⚡</div>
                <div>
                  <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>CAMPUS ENERGY</div>
                  <div>87% Renewable Grid</div>
                </div>
              </div>

              <div className="tc-hero-badge-float badge-bottom-left">
                <div className="tc-badge-icon">📊</div>
                <div>
                  <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>IMPACT VISION</div>
                  <div>Connected Indicators</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. About Teraconnect */}
      <section id="about" className="tc-section tc-about-section">
        <div className="tc-container">
          <div className="tc-about-grid">
            <div className="tc-about-text-content">
              <h2>What Is Teraconnect?</h2>
              <p>
                Teraconnect is a sustainability management platform designed to connect organisations with the tools, information, and actions needed to improve their sustainability practices. Our aim is to make sustainability easier to understand, organise, monitor, and act upon.
              </p>
              <p>
                From tracking carbon emissions and managing waste to improving energy and water efficiency, promoting responsible resource use, and encouraging community participation, Teraconnect brings different dimensions of sustainability into one connected vision.
              </p>
              <p>
                Our mission is to help organisations move beyond isolated initiatives and build a more structured approach to sustainability—one where progress can be tracked, goals can be pursued, and every improvement can contribute to a more responsible future.
              </p>
            </div>

            {/* Compact Connected Dimensions Overview */}
            <div className="tc-about-mockup">
              <div className="tc-mockup-header">
                <span className="tc-mockup-title">
                  <span>🌿</span> Connected Operations
                </span>
                <span className="tc-mockup-pill">Active Telemetry</span>
              </div>

              <div className="tc-mockup-stat-row">
                <div className="tc-mockup-stat-card">
                  <span className="tc-stat-label">Energy Efficiency</span>
                  <span className="tc-stat-value">94.2%</span>
                  <div className="tc-stat-progress">
                    <div className="tc-stat-progress-bar" style={{ width: '94%' }}></div>
                  </div>
                </div>

                <div className="tc-mockup-stat-card">
                  <span className="tc-stat-label">Waste Diversion</span>
                  <span className="tc-stat-value">88.5%</span>
                  <div className="tc-stat-progress">
                    <div className="tc-stat-progress-bar" style={{ width: '88%' }}></div>
                  </div>
                </div>
              </div>

              <div className="tc-mockup-stream-list">
                <div className="tc-stream-item">
                  <span className="tc-stream-name">
                    <span>⚡</span> Clean Energy &amp; Water Audit
                  </span>
                  <span className="tc-stream-status">Optimized ✓</span>
                </div>
                <div className="tc-stream-item">
                  <span className="tc-stream-name">
                    <span>🔄</span> Segregation &amp; Material Reuse
                  </span>
                  <span className="tc-stream-status">Active ✓</span>
                </div>
                <div className="tc-stream-item">
                  <span className="tc-stream-name">
                    <span>👥</span> Community Eco-Leadership
                  </span>
                  <span className="tc-stream-status">Connected ✓</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Our Purpose */}
      <section id="approach" className="tc-section tc-purpose-section">
        <div className="tc-container">
          <div className="tc-section-header">
            <h2 className="tc-section-title">Why We Exist</h2>
          </div>

          <div className="tc-purpose-intro-card">
            <p>
              Many organisations want to become more sustainable but struggle to organise information, identify priorities, and measure progress. Sustainability efforts can become disconnected when resource consumption, waste, emissions, and initiatives are managed separately.
            </p>
            <p>
              Teraconnect aims to bridge this gap by providing a connected platform where organisations can understand their impact, coordinate initiatives, monitor relevant indicators, and work towards clear sustainability goals. We believe meaningful progress begins with awareness, grows through informed action, and becomes stronger through continuous improvement.
            </p>
          </div>

          {/* 3 Benefit Cards */}
          <div className="tc-benefit-cards-grid">
            <div className="tc-benefit-card">
              <div className="tc-benefit-icon-wrap">🔍</div>
              <h3>Understand Your Impact</h3>
              <p>
                Organise sustainability information and identify areas where improvement is needed.
              </p>
            </div>

            <div className="tc-benefit-card">
              <div className="tc-benefit-icon-wrap">🎯</div>
              <h3>Take Informed Action</h3>
              <p>
                Coordinate initiatives, set practical goals, and encourage responsible resource use.
              </p>
            </div>

            <div className="tc-benefit-card">
              <div className="tc-benefit-icon-wrap">📈</div>
              <h3>Measure Your Progress</h3>
              <p>
                Monitor relevant indicators, review results, and identify opportunities for further improvement.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Sustainability Is More Than Greenery */}
      <section id="sustainability-areas" className="tc-section tc-impact-section">
        <div className="tc-container">
          <div className="tc-section-header">
            <h2 className="tc-section-title">One Mission. Many Areas of Impact.</h2>
            <p className="tc-section-subtitle">
              Sustainable development connects environmental responsibility, social well-being, and long-term economic resilience. Teraconnect recognises that progress requires attention to the systems, resources, and communities that shape our everyday lives.
            </p>
          </div>

          {/* 6 Image-Led Cards Grid */}
          <div className="tc-impact-grid">
            {/* 1. Carbon & Climate */}
            <div className="tc-impact-card">
              <div className="tc-impact-banner banner-carbon">
                <span className="tc-impact-graphic">☁️</span>
                <span className="tc-impact-overlay-badge">Emissions Tracking</span>
              </div>
              <div className="tc-impact-body">
                <h3 className="tc-impact-title">Carbon &amp; Climate</h3>
                <p className="tc-impact-desc">
                  Understand emissions sources and work towards reducing climate impact.
                </p>
              </div>
            </div>

            {/* 2. Waste & Circular Economy */}
            <div className="tc-impact-card">
              <div className="tc-impact-banner banner-waste">
                <span className="tc-impact-graphic">🔄</span>
                <span className="tc-impact-overlay-badge">Circular Materials</span>
              </div>
              <div className="tc-impact-body">
                <h3 className="tc-impact-title">Waste &amp; Circular Economy</h3>
                <p className="tc-impact-desc">
                  Reduce waste, improve segregation, encourage reuse, and support recycling.
                </p>
              </div>
            </div>

            {/* 3. Energy & Water */}
            <div className="tc-impact-card">
              <div className="tc-impact-banner banner-energy">
                <span className="tc-impact-graphic">⚡</span>
                <span className="tc-impact-overlay-badge">Resource Efficiency</span>
              </div>
              <div className="tc-impact-body">
                <h3 className="tc-impact-title">Energy &amp; Water</h3>
                <p className="tc-impact-desc">
                  Monitor consumption, identify inefficiencies, and encourage responsible use.
                </p>
              </div>
            </div>

            {/* 4. Resources & Transportation */}
            <div className="tc-impact-card">
              <div className="tc-impact-banner banner-transport">
                <span className="tc-impact-graphic">🚊</span>
                <span className="tc-impact-overlay-badge">Mobility &amp; Supply</span>
              </div>
              <div className="tc-impact-body">
                <h3 className="tc-impact-title">Resources &amp; Transportation</h3>
                <p className="tc-impact-desc">
                  Promote efficient material use and explore lower-impact mobility.
                </p>
              </div>
            </div>

            {/* 5. Nature & Biodiversity */}
            <div className="tc-impact-card">
              <div className="tc-impact-banner banner-nature">
                <span className="tc-impact-graphic">🌿</span>
                <span className="tc-impact-overlay-badge">Ecosystem Corridors</span>
              </div>
              <div className="tc-impact-body">
                <h3 className="tc-impact-title">Nature &amp; Biodiversity</h3>
                <p className="tc-impact-desc">
                  Support ecosystem protection and responsible environmental initiatives.
                </p>
              </div>
            </div>

            {/* 6. People & Communities */}
            <div className="tc-impact-card">
              <div className="tc-impact-banner banner-people">
                <span className="tc-impact-graphic">👥</span>
                <span className="tc-impact-overlay-badge">Social Well-being</span>
              </div>
              <div className="tc-impact-body">
                <h3 className="tc-impact-title">People &amp; Communities</h3>
                <p className="tc-impact-desc">
                  Encourage education, inclusion, awareness, and collective participation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. How Teraconnect Works */}
      <section className="tc-section tc-flow-section">
        <div className="tc-container">
          <div className="tc-section-header">
            <h2 className="tc-section-title">From Awareness to Action.</h2>
            <p className="tc-section-subtitle">
              A structured, continuous cycle enabling organisations to move from understanding their baseline to executing measurable impact.
            </p>
          </div>

          <div className="tc-timeline-grid">
            <div className="tc-timeline-step-card">
              <span className="tc-step-num-pill">01 — Understand</span>
              <h3>Understand</h3>
              <p>
                Organise relevant information about your organisation's sustainability activities and resource use.
              </p>
            </div>

            <div className="tc-timeline-step-card">
              <span className="tc-step-num-pill">02 — Set Goals</span>
              <h3>Set Goals</h3>
              <p>
                Identify priorities and establish practical, measurable improvement targets.
              </p>
            </div>

            <div className="tc-timeline-step-card">
              <span className="tc-step-num-pill">03 — Take Action</span>
              <h3>Take Action</h3>
              <p>
                Coordinate initiatives and involve the people responsible for making improvements.
              </p>
            </div>

            <div className="tc-timeline-step-card">
              <span className="tc-step-num-pill">04 — Track Progress</span>
              <h3>Track Progress</h3>
              <p>
                Review results, learn from outcomes, and identify the next opportunities for improvement.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 9. Who Can Join? */}
      <section className="tc-section tc-audience-section">
        <div className="tc-container">
          <div className="tc-section-header">
            <h2 className="tc-section-title">Sustainability Is a Shared Responsibility.</h2>
            <p className="tc-section-subtitle">
              Every organisation has a role to play in building a sustainable future. Teraconnect aims to support organisations of different sizes and backgrounds as they organise their efforts and pursue meaningful improvements.
            </p>
          </div>

          <div className="tc-audience-grid">
            <div className="tc-audience-card">
              <div className="tc-audience-icon">🏫</div>
              <h3>Schools &amp; Universities</h3>
              <p>Build awareness and support more sustainable campuses.</p>
            </div>

            <div className="tc-audience-card">
              <div className="tc-audience-icon">🏢</div>
              <h3>Businesses &amp; Corporations</h3>
              <p>Improve resource efficiency and organise sustainability initiatives.</p>
            </div>

            <div className="tc-audience-card">
              <div className="tc-audience-icon">🤝</div>
              <h3>Clubs &amp; Associations</h3>
              <p>Coordinate community projects and encourage participation.</p>
            </div>

            <div className="tc-audience-card">
              <div className="tc-audience-icon">🏡</div>
              <h3>Communities &amp; Other Organisations</h3>
              <p>Work together on local sustainability priorities.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 10. Final Call to Action */}
      <section id="join" className="tc-cta-section">
        <div className="tc-cta-ambient-mesh" aria-hidden="true"></div>
        <div className="tc-container tc-cta-content">
          <span className="tc-cta-eyebrow">LET'S BUILD A BETTER FUTURE</span>
          <h2 className="tc-cta-title">Your Sustainability Journey Starts Here.</h2>
          <p className="tc-cta-p">
            Whether your organisation is taking its first steps or building on existing sustainability initiatives, Teraconnect invites you to turn your intentions into organised action. Connect with a more informed, responsible, and measurable approach to sustainability.
          </p>
          <div className="tc-cta-btn-wrap">
            <button
              type="button"
              onClick={onNavigateToJoin}
              className="tc-btn-cta-main"
            >
              Join the Teraconnect Network &rarr;
            </button>
          </div>
          <p className="tc-cta-subtext">
            Bring your organisation on board and take the first step towards meaningful sustainability progress.
          </p>
        </div>
      </section>

      {/* 11. Footer */}
      <footer className="tc-footer">
        <div className="tc-container">
          <div className="tc-footer-grid">
            <div className="tc-footer-brand">
              <div className="tc-footer-logo-row">
                <img
                  src={teraloopLogo}
                  alt="Teraconnect Logo"
                  className="tc-footer-logo"
                />
                <span className="tc-footer-brand-title">Teraconnect</span>
              </div>
              <p className="tc-footer-statement">
                Teraconnect is a connected sustainability management platform designed to help schools, universities, businesses, and communities understand their environmental impact, manage resources responsibly, and achieve measurable improvements.
              </p>
            </div>

            <div className="tc-footer-nav-col">
              <ul className="tc-footer-nav-list">
                <li>
                  <button
                    type="button"
                    onClick={() => scrollToSection('about')}
                    className="tc-footer-link"
                  >
                    About
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => scrollToSection('approach')}
                    className="tc-footer-link"
                  >
                    Our Approach
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => scrollToSection('sustainability-areas')}
                    className="tc-footer-link"
                  >
                    Sustainability Areas
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={onNavigateToJoin}
                    className="tc-footer-link"
                  >
                    Join the Network
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="tc-footer-bottom">
            <span>&copy; 2026 Teraconnect. All rights reserved.</span>
            <span>Sustainable Tomorrow, Together.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default AboutPage;
